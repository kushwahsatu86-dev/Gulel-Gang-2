GULEL GANG - Android APK Project (with app icon)

Is project mein:
- Game HTML app/src/main/assets/index.html mein bundled hai.
- Gulel Gang custom launcher icon mipmap folders mein add hai.
- AndroidManifest.xml mein app icon set hai.
- GitHub Actions workflow .github/workflows/build-apk.yml mein hai.

Mobile se build:
ZIP ko phone mein extract karo. GitHub par ZIP ko seedha upload karne se project files extract nahi hoti.
Phone par Termux (F-Droid se) install karke project folder mein jao, phir git init/add/commit,
GitHub repository remote set karke git push karo. Isse .github workflow bhi repository mein jayega.
Uske baad GitHub > Actions > Build Gulel Gang APK > Run workflow.
Build successful hone par Artifacts se Gulel-Gang-debug-APK download karke extract karo.

Note: Debug APK compile karne ke liye GitHub Actions cloud runner use hota hai.
Game mein external CDN library ho to internet connection required ho sakta hai.
